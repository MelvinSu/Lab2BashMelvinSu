#!/bin/sh

cat Melvin_862044613.txt > main.cc

echo "int main(int argc, const char** argv)" >> main.cc
echo "{ }" >> main.cc
